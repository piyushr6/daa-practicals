import pandas as pd
import matplotlib.pyplot as plt

# Read CSV file
df = pd.read_csv("closestpair.csv")

# Plot
plt.figure(figsize=(10, 6))
plt.plot(df["Size"], df["BruteForce"], label="Brute Force (O(n²))", color="red", linestyle="dashed")
plt.plot(df["Size"], df["DivideAndConquer"], label="Divide & Conquer (O(n log n))", color="blue")

# Labels and Title
plt.xlabel("Number of Points (n)")
plt.ylabel("Execution Time (ms)")
#plt.yscale("log")
plt.title("Closest Pair Algorithm Performance")
plt.legend()
plt.grid()

# Save the figure
plt.savefig("performance_plot.png")
plt.show()
