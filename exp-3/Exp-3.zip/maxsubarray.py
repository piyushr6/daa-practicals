import pandas as pd
import matplotlib.pyplot as plt

# Load the CSV file
df = pd.read_csv("maxsubarray.csv")

# Create a single plot
fig, ax = plt.subplots(figsize=(10, 12))

# Plot the data on the single subplot
ax.plot(df["size"], df["kadene"], color="blue", label="kadene")
ax.plot(df["size"], df["Brute"], color="green", label="Brute")
ax.plot(df["size"], df["Divide"], color="red", label="Divide")

# Set plot title and labels
ax.set_title("Max SubArray Timings")
ax.set_ylabel("Time (ms)")
ax.set_xlabel("Array Size")

# Add legend
ax.legend()

# Set y-axis to logarithmic scale
#ax.set_yscale("log")

# Adjust layout and save the plot
plt.tight_layout()
#plt.savefig("result.jpg", dpi=400)

# Show the plot
plt.show()

