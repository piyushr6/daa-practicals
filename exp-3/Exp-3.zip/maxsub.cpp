#include <bits/stdc++.h>
using namespace std;

void generateRandomFile(const string& filename, long size) {
    ofstream fout(filename);
    if (!fout) {
        cerr << "Error opening file for writing!" << endl;
        return;
    }

    random_device rd;
    mt19937 gen(rd());
    uniform_int_distribution<long> dist(1, 1e6);

    for (long i = 0; i < size; i++) {
        fout << dist(gen) - 5 * 1e5 << "\n"; // Ensures negative values are also generated
    }
    fout.close();
}

vector<long> readRandomFile(const string& filename, long size) {
    ifstream fin(filename);
    if (!fin) {
        cerr << "Error opening file for reading!" << endl;
        return {};
    }

    vector<long> arr(size);
    for (long i = 0; i < size && fin >> arr[i]; i++);
    fin.close();
    return arr;
}

// Kadane's algorithm to find the maximum subarray sum
long kadene(vector<long>& a, vector<long>& subarray) {
    long curr = 0;
    long maximum = LONG_MIN; // Handle negative numbers correctly
    long start = 0, end = 0, tempStart = 0;
    for (long i = 0; i < a.size(); i++) {
        curr += a[i];
        if (curr > maximum) {
            maximum = curr;
            start = tempStart;
            end = i;
        }
        if (curr < 0) {
            curr = 0;
            tempStart = i + 1;
        }
    }
    subarray.clear();
    for (long i = start; i <= end; i++) {
        subarray.push_back(a[i]);
    }
    return maximum;
}

// Brute-force method to find the maximum subarray sum
long Brute(vector<long>& a, vector<long>& subarray) {
    long maxSum = LONG_MIN;
    size_t bestStart = 0, bestEnd = 0;
    for (size_t i = 0; i < a.size(); i++) {
        long sum = 0;
        for (size_t j = i; j < a.size(); j++) {
            sum += a[j];
            if (sum > maxSum) {
                maxSum = sum;
                bestStart = i;
                bestEnd = j;
            }
        }
    }
    subarray.clear();
    for (size_t i = bestStart; i <= bestEnd; i++) {
        subarray.push_back(a[i]);
    }
    return maxSum;
}

// Helper function for divide-and-conquer method to calculate max crossing sum
long maxCrossingSum(vector<long>& a, int left, int mid, int right) {
    long leftSum = LONG_MIN, rightSum = LONG_MIN;
    long sum = 0;

    // Calculate left half sum
    for (int i = mid; i >= left; i--) {
        sum += a[i];
        leftSum = max(leftSum, sum);
    }

    // Calculate right half sum
    sum = 0;
    for (int i = mid + 1; i <= right; i++) {
        sum += a[i];
        rightSum = max(rightSum, sum);
    }

    return leftSum + rightSum;
}

// Divide-and-conquer function to find the maximum subarray sum
long divi(vector<long>& a, int left, int right, vector<long>& subarray) {
    if (left == right) {
        subarray.push_back(a[left]); // Base case: single element
        return a[left];
    }

    int mid = left + (right - left) / 2;

    vector<long> leftSubarray, rightSubarray, crossSubarray;

    long leftMax = divi(a, left, mid, leftSubarray);
    long rightMax = divi(a, mid + 1, right, rightSubarray);
    long crossMax = maxCrossingSum(a, left, mid, right);

    if (leftMax >= rightMax && leftMax >= crossMax) {
        subarray = leftSubarray;
        return leftMax;
    } else if (rightMax >= leftMax && rightMax >= crossMax) {
        subarray = rightSubarray;
        return rightMax;
    } else {
        subarray = leftSubarray;
        subarray.insert(subarray.end(), rightSubarray.begin(), rightSubarray.end());
        return crossMax;
    }
}

void divide(vector<long>& a, vector<long>& subarray) {
    if (!a.empty()) {
        divi(a, 0, a.size() - 1, subarray);
    }
}

// Function to measure and write execution time for all algorithms
void get(vector<long> a, ofstream& fout, ofstream& subarrayOut) {
    using namespace std::chrono;

    vector<long> b = a, c = a;
    vector<long> kadSubarray, bruteSubarray, divSubarray;

    auto t0 = high_resolution_clock::now();
    long kadeneResult = kadene(a, kadSubarray);
    auto t1 = high_resolution_clock::now();
    auto kad = duration_cast<nanoseconds>(t1 - t0);

    auto t2 = high_resolution_clock::now();
    long bruteResult = Brute(b, bruteSubarray);
    auto t3 = high_resolution_clock::now();
    auto bru = duration_cast<nanoseconds>(t3 - t2);

    auto t4 = high_resolution_clock::now();
    long divResult = divi(c, 0, c.size() - 1, divSubarray);
    auto t5 = high_resolution_clock::now();
    auto div = duration_cast<nanoseconds>(t5 - t4);

    fout << a.size() << ","
         << kad.count() << ","
         << bru.count() << ","
         << div.count() << endl;

    // Write subarrays to the separate CSV file
    subarrayOut << a.size() << ","
                << kadeneResult << ",[";
    for (long num : kadSubarray) subarrayOut << num << ",";
    subarrayOut.seekp(-1, ios_base::end); // Remove last comma
    subarrayOut << "]," << endl;

    subarrayOut << a.size() << ","
                << bruteResult << ",[";
    for (long num : bruteSubarray) subarrayOut << num << ",";
    subarrayOut.seekp(-1, ios_base::end);
    subarrayOut << "]," << endl;

    subarrayOut << a.size() << ","
                << divResult << ",[";
    for (long num : divSubarray) subarrayOut << num << ",";
    subarrayOut.seekp(-1, ios_base::end);
    subarrayOut << "]," << endl;
}

int main() {
    const string filename = "random.txt";
    const long dataSize = 100000;
    generateRandomFile(filename, dataSize);
    ofstream fout("exp3.csv");
    ofstream subarrayOut("subarrays.csv");
    fout << "size,kadene,Brute,Divide" << endl;
    subarrayOut << "size,MaxSum,Subarray" << endl;

    for (int i = 100; i <= 100000; i += 100) { // Reduced size limit for faster execution
        cout << "Processing size: " << i << endl;
        vector<long> a = readRandomFile(filename, i);
        get(a, fout, subarrayOut);
    }

    fout.close();
    subarrayOut.close();
}

