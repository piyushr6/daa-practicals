#include <iostream>
#include <vector>
#include <chrono>
#include <fstream>
#include <cstdlib>
#include <ctime>

using namespace std;
using namespace std::chrono;

const int BASE_THRESHOLD = 64;  // Optimized threshold for Strassen's method

vector<vector<long>> bruteForce(const vector<vector<long>> &A, const vector<vector<long>> &B) {
    int n = A.size();
    vector<vector<long>> C(n, vector<long>(n, 0));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            for (int k = 0; k < n; k++)
                C[i][j] += A[i][k] * B[k][j];
    return C;
}

vector<vector<long>> addMatrix(const vector<vector<long>> &X, const vector<vector<long>> &Y) {
    int n = X.size();
    vector<vector<long>> result(n, vector<long>(n));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            result[i][j] = X[i][j] + Y[i][j];
    return result;
}

vector<vector<long>> subMatrix(const vector<vector<long>> &X, const vector<vector<long>> &Y) {
    int n = X.size();
    vector<vector<long>> result(n, vector<long>(n));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            result[i][j] = X[i][j] - Y[i][j];
    return result;
}

vector<vector<long>> divideAndConquer(const vector<vector<long>> &A, const vector<vector<long>> &B) {
    int n = A.size();
    if (n <= BASE_THRESHOLD) return bruteForce(A, B);

    int mid = n / 2;
    vector<vector<long>> C(n, vector<long>(n, 0));

    auto subMatrixView = [&](const vector<vector<long>> &M, int row, int col) {
        vector<vector<long>> sub(mid, vector<long>(mid));
        for (int i = 0; i < mid; i++)
            for (int j = 0; j < mid; j++)
                sub[i][j] = M[row + i][col + j];
        return sub;
    };

    vector<vector<long>> a = subMatrixView(A, 0, 0), b = subMatrixView(A, 0, mid);
    vector<vector<long>> c = subMatrixView(A, mid, 0), d = subMatrixView(A, mid, mid);
    vector<vector<long>> e = subMatrixView(B, 0, 0), f = subMatrixView(B, 0, mid);
    vector<vector<long>> g = subMatrixView(B, mid, 0), h = subMatrixView(B, mid, mid);

    auto c00 = addMatrix(divideAndConquer(a, e), divideAndConquer(b, g));
    auto c01 = addMatrix(divideAndConquer(a, f), divideAndConquer(b, h));
    auto c10 = addMatrix(divideAndConquer(c, e), divideAndConquer(d, g));
    auto c11 = addMatrix(divideAndConquer(c, f), divideAndConquer(d, h));

    for (int i = 0; i < mid; i++)
        for (int j = 0; j < mid; j++) {
            C[i][j] = c00[i][j];
            C[i][j + mid] = c01[i][j];
            C[i + mid][j] = c10[i][j];
            C[i + mid][j + mid] = c11[i][j];
        }
    return C;
}

vector<vector<long>> strassen(const vector<vector<long>> &A, const vector<vector<long>> &B) {
    int n = A.size();
    if (n <= BASE_THRESHOLD) return bruteForce(A, B);

    int mid = n / 2;
    vector<vector<long>> C(n, vector<long>(n, 0));

    auto subMatrixView = [&](const vector<vector<long>> &M, int row, int col) {
        vector<vector<long>> sub(mid, vector<long>(mid));
        for (int i = 0; i < mid; i++)
            for (int j = 0; j < mid; j++)
                sub[i][j] = M[row + i][col + j];
        return sub;
    };

    vector<vector<long>> a = subMatrixView(A, 0, 0), b = subMatrixView(A, 0, mid);
    vector<vector<long>> c = subMatrixView(A, mid, 0), d = subMatrixView(A, mid, mid);
    vector<vector<long>> e = subMatrixView(B, 0, 0), f = subMatrixView(B, 0, mid);
    vector<vector<long>> g = subMatrixView(B, mid, 0), h = subMatrixView(B, mid, mid);

    vector<vector<long>> p1 = strassen(a, subMatrix(f, h));
    vector<vector<long>> p2 = strassen(addMatrix(a, b), h);
    vector<vector<long>> p3 = strassen(addMatrix(c, d), e);
    vector<vector<long>> p4 = strassen(d, subMatrix(g, e));
    vector<vector<long>> p5 = strassen(addMatrix(a, d), addMatrix(e, h));
    vector<vector<long>> p6 = strassen(subMatrix(b, d), addMatrix(g, h));
    vector<vector<long>> p7 = strassen(subMatrix(a, c), addMatrix(e, f));

    for (int i = 0; i < mid; i++)
        for (int j = 0; j < mid; j++) {
            C[i][j] = p5[i][j] + p4[i][j] - p2[i][j] + p6[i][j];
            C[i][j + mid] = p1[i][j] + p2[i][j];
            C[i + mid][j] = p3[i][j] + p4[i][j];
            C[i + mid][j + mid] = p1[i][j] + p5[i][j] - p3[i][j] - p7[i][j];
        }
    return C;
}

int main() {
    srand(time(0));
    ofstream file("result.csv");
    file << "Size,BruteForce,DivideAndConquer,Strassen\n";

    for (int i =1;i<15;i++) {
        int size = 1<<i;
        vector<vector<long>> A(size, vector<long>(size, rand() % 10));
        vector<vector<long>> B(size, vector<long>(size, rand() % 10));
        cout << "Processing size: " << size << endl;

        auto start = high_resolution_clock::now();
        bruteForce(A, B);
        auto stop = high_resolution_clock::now();
        file << size << "," << duration<double, milli>(stop - start).count();

        start = high_resolution_clock::now();
        divideAndConquer(A, B);
        stop = high_resolution_clock::now();
        file << "," << duration<double, milli>(stop - start).count();

        start = high_resolution_clock::now();
        strassen(A, B);
        stop = high_resolution_clock::now();
        file << "," << duration<double, milli>(stop - start).count() << "\n";
        file.flush();
    }

    file.close();
    cout << "Results saved to result.csv\n";
    return 0;
}

