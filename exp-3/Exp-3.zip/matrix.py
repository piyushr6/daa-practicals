import pandas as pd
import matplotlib.pyplot as plt

# Load CSV file
df = pd.read_csv("matrix.csv")

# Plot
plt.figure(figsize=(10, 6))
plt.plot(df["Size"], df["BruteForce"],  label="Brute Force")
plt.plot(df["Size"], df["DivideAndConquer"], label="Divide & Conquer")
plt.plot(df["Size"], df["Strassen"], label="Strassen")
plt.xscale("log", base=2)
#plt.yscale("log")
plt.xlabel("Matrix Size (NxN)")
plt.ylabel("Time (ms) Log scale")
plt.title("Matrix Multiplication Performance")
plt.legend()
plt.grid(True, which="both", linestyle="--", linewidth=0.5)
plt.savefig("resultLogScale.png",dpi=400)
plt.show()


