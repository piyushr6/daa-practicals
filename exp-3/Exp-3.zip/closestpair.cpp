#include <iostream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <limits>
#include <fstream>
#include <chrono>
#include <cstdlib>

using namespace std;
using namespace chrono;

struct Point {
    long x, y;
};

double euclideanDist(const Point &p1, const Point &p2) {
    return sqrt((p1.x - p2.x) * (p1.x - p2.x) + (p1.y - p2.y) * (p1.y - p2.y));
}

double bruteForce(const vector<Point> &points) {
    double minDist = numeric_limits<double>::max();
    int n = points.size();
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            double dist = euclideanDist(points[i], points[j]);
            minDist = min(minDist, dist);
        }
    }
    return minDist;
}

double stripClosest(vector<Point> &strip, double d) {
    double minDist = d;
    sort(strip.begin(), strip.end(), [](Point a, Point b) { return a.y < b.y; });

    int n = strip.size();
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n && (strip[j].y - strip[i].y) < minDist; j++) {
            minDist = min(minDist, euclideanDist(strip[i], strip[j]));
        }
    }
    return minDist;
}

double closestPairRecursive(vector<Point> &Px, vector<Point> &Py, int left, int right) {
    int n = right - left;
    if (n <= 3) {
        return bruteForce(vector<Point>(Px.begin() + left, Px.begin() + right));
    }

    int mid = left + n / 2;
    Point midPoint = Px[mid];

    vector<Point> Pyl, Pyr;
    for (int i = 0; i < Py.size(); i++) {
        if (Py[i].x <= midPoint.x) Pyl.push_back(Py[i]);
        else Pyr.push_back(Py[i]);
    }

    double dl = closestPairRecursive(Px, Pyl, left, mid);
    double dr = closestPairRecursive(Px, Pyr, mid, right);
    double d = min(dl, dr);

    vector<Point> strip;
    for (int i = 0; i < Py.size(); i++) {
        if (abs(Py[i].x - midPoint.x) < d) strip.push_back(Py[i]);
    }

    return min(d, stripClosest(strip, d));
}

// Wrapper function to call recursion
double closestPair(vector<Point> &points) {
    vector<Point> Px = points, Py = points;
    sort(Px.begin(), Px.end(), [](Point a, Point b) { return a.x < b.x; });
    sort(Py.begin(), Py.end(), [](Point a, Point b) { return a.y < b.y; });

    return closestPairRecursive(Px, Py, 0, Px.size());
}


int main() {
    srand(time(0));
    ofstream file("result.csv");
    file << "Size,BruteForce,DivideAndConquer\n";

    for (int i = 100; i <= 50000; i += 100) { // Limited to 5000 for practical runtime
        vector<Point> points(i);
        for (int j = 0; j < i; j++) {
            points[j] = {rand() % 10000, rand() % 10000};
        }

        cout << "Processing size: " << i << endl;

        auto start = high_resolution_clock::now();
        bruteForce(points);
        auto stop = high_resolution_clock::now();
        file << i << "," << duration<double, milli>(stop - start).count();

        start = high_resolution_clock::now();
        closestPair(points);
        stop = high_resolution_clock::now();
        file << "," << duration<double, milli>(stop - start).count() << "\n";

        file.flush();
    }

    file.close();
    cout << "Results saved to result.csv\n";
    return 0;
}

